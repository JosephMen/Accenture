Buen dia.
 - Detalles del proyecto: Me tomo alrededor de 2 días completar el proyecto y un dia mas para documentarlo y organizarlo, lo cual no era difícil, de hecho era muy simple la programación en groovy. Se hizo completamente en consola aunque no se descartaba hacerlo con gui pero esto tomaría más tiempo.

 - Hay un log que se muestra en consola que muestra el avance de los procesos y ademas también se guarda en un archivo .txt mas detalles del proceso y se registra los errores.

 - Hay una carpeta de prueba con archivos txt con contenido dentro y una subcarpeta con un archivo el cual no tiene nada escrito y el cual no deberia encontrar un patrón por lo cual no se modifica y no se respalda.

 - Para facilidad de pruebas puede elegir en dejar algunos inputs en blanco para que este use la carpeta en donde se encuentra el archivo .groovy. 

 - Se recomienda usar como patron de busqueda: "que" y como palabra para remplazar: "modificado.que"